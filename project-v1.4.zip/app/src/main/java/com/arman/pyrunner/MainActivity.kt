package com.arman.pyrunner

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.arman.pyrunner.databinding.ActivityMainBinding
import com.chaquo.python.Python
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ScriptAdapter
    private val scriptsDir by lazy { File(filesDir, "scripts").also { it.mkdirs() } }
    private var currentFile: File? = null
    private var running = false
    private val PICK = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Python initialized in App.kt

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupDrawer()
        setupButtons()
        loadScriptList()
    }

    private fun setupDrawer() {
        adapter = ScriptAdapter(
            onRun = { file -> loadScript(file); runScript() },
            onDelete = { file -> confirmDelete(file) }
        )
        binding.rvScripts.layoutManager = LinearLayoutManager(this)
        binding.rvScripts.adapter = adapter
    }

    private fun setupButtons() {
        binding.btnMenu.setOnClickListener {
            if (binding.drawerLayout.isDrawerOpen(GravityCompat.START))
                binding.drawerLayout.closeDrawer(GravityCompat.START)
            else
                binding.drawerLayout.openDrawer(GravityCompat.START)
        }
        binding.btnUpload.setOnClickListener { pickFile() }
        binding.btnRun.setOnClickListener { runScript() }
        binding.btnSave.setOnClickListener { saveFile() }
        binding.btnNewScript.setOnClickListener { newScript() }
        binding.btnClearOutput.setOnClickListener {
            binding.tvOutput.text = ""
            binding.tvOutputLabel.visibility = View.GONE
        }
        binding.actionMore.setOnClickListener { showMore(it) }
    }

    private fun showMore(anchor: View) {
        val pop = PopupMenu(this, anchor)
        pop.menu.apply {
            add(0, 1, 0, "নতুন স্ক্রিপ্ট")
            add(0, 2, 1, "বর্তমান ফাইল সেভ করুন")
            add(0, 3, 2, "আউটপুট কপি করুন")
        }
        pop.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> newScript()
                2 -> saveFile()
                3 -> copyOutput()
            }
            true
        }
        pop.show()
    }

    // ── File operations ────────────────────────────────

    private fun pickFile() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(i, ".py ফাইল সিলেক্ট করুন"), PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == PICK && res == Activity.RESULT_OK) {
            data?.data?.let { importScript(it) }
        }
    }

    private fun importScript(uri: Uri) {
        try {
            val raw = getFileName(uri)
            val name = if (raw.endsWith(".py")) raw else "$raw.py"
            val dest = File(scriptsDir, name)
            contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            loadScript(dest)
            loadScriptList()
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            toast("✅ $name আপলোড হয়েছে")
        } catch (e: Exception) {
            toast("❌ আপলোড ব্যর্থ: ${e.message}")
        }
    }

    private fun loadScript(file: File) {
        currentFile = file
        binding.etCode.setText(file.readText())
        binding.tvCurrentScript.text = file.name
        binding.tvCurrentScript.visibility = View.VISIBLE
        binding.btnSave.visibility = View.VISIBLE
        binding.tvOutput.text = ""
        binding.tvOutputLabel.visibility = View.GONE
        binding.drawerLayout.closeDrawer(GravityCompat.START)
    }

    private fun saveFile() {
        val file = currentFile ?: run {
            val n = "script_${System.currentTimeMillis()}.py"
            File(scriptsDir, n).also { currentFile = it }
        }
        file.writeText(binding.etCode.text.toString())
        binding.tvCurrentScript.text = file.name
        binding.tvCurrentScript.visibility = View.VISIBLE
        loadScriptList()
        toast("💾 সেভ হয়েছে")
    }

    private fun newScript() {
        currentFile = null
        binding.etCode.setText("")
        binding.tvCurrentScript.text = "(নতুন)"
        binding.tvCurrentScript.visibility = View.VISIBLE
        binding.btnSave.visibility = View.VISIBLE
        binding.tvOutput.text = ""
        binding.tvOutputLabel.visibility = View.GONE
        binding.drawerLayout.closeDrawer(GravityCompat.START)
    }

    private fun confirmDelete(file: File) {
        AlertDialog.Builder(this)
            .setTitle("ডিলিট করুন")
            .setMessage("\"${file.name}\" ডিলিট করবেন?")
            .setPositiveButton("হ্যাঁ") { _, _ ->
                file.delete()
                if (currentFile?.name == file.name) {
                    currentFile = null
                    binding.etCode.setText("")
                    binding.tvCurrentScript.visibility = View.GONE
                    binding.btnSave.visibility = View.GONE
                }
                loadScriptList()
                toast("🗑 ডিলিট হয়েছে")
            }
            .setNegativeButton("না", null).show()
    }

    private fun loadScriptList() {
        val files = scriptsDir.listFiles()
            ?.filter { it.extension == "py" }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
        adapter.setItems(files)
        binding.tvNoScripts.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
    }

    // ── Python execution ───────────────────────────────

    private fun runScript() {
        val code = binding.etCode.text.toString().trim()
        if (code.isEmpty()) { toast("স্ক্রিপ্ট ফাঁকা!"); return }
        if (running) { toast("ইতিমধ্যে চলছে..."); return }

        if (!App.pythonReady) {
            val err = App.pythonError ?: "Python লোড হয়নি"
            toast("❌ $err")
            binding.tvOutputLabel.visibility = android.view.View.VISIBLE
            binding.tvOutput.text = "Python runtime লোড হয়নি।\n\nকারণ: $err\n\nফোন restart করে আবার চেষ্টা করুন।"
            return
        }

        running = true
        binding.btnRun.isEnabled = false
        binding.progressBar.visibility = View.VISIBLE
        binding.tvOutputLabel.visibility = View.VISIBLE
        binding.tvOutput.text = ""

        val fileName = currentFile?.name ?: "script.py"

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { execPython(code, fileName) }
            binding.tvOutput.text = result
            binding.scrollOutput.post { binding.scrollOutput.fullScroll(View.FOCUS_DOWN) }
            binding.btnRun.isEnabled = true
            binding.progressBar.visibility = View.GONE
            running = false
        }
    }

    private fun execPython(code: String, name: String): String {
        return try {
            val py = Python.getInstance()
            val io = py.getModule("io")
            val sys = py.getModule("sys")
            val b = py.getBuiltins()

            val out = io.callAttr("StringIO")
            val err = io.callAttr("StringIO")
            val origOut = sys["stdout"]
            val origErr = sys["stderr"]
            sys["stdout"] = out
            sys["stderr"] = err

            var execErr: String? = null
            try {
                b.callAttr("exec", b.callAttr("compile", code, name, "exec"))
            } catch (e: Exception) {
                execErr = e.message?.replace("com.chaquo.python.PyException: ", "")?.trim()
            } finally {
                sys["stdout"] = origOut
                sys["stderr"] = origErr
            }

            buildString {
                val o = out.callAttr("getvalue").toString()
                val e = err.callAttr("getvalue").toString()
                if (o.isNotEmpty()) append(o)
                if (e.isNotEmpty()) { if (o.isNotEmpty()) append("\n"); append("── stderr ──\n$e") }
                if (execErr != null) { if (isNotEmpty()) append("\n"); append("── error ──\n$execErr") }
                if (isEmpty()) append("(কোনো আউটপুট নেই)")
            }
        } catch (e: Exception) {
            "❌ Critical error: ${e.message}"
        }
    }

    // ── Helpers ────────────────────────────────────────

    private fun getFileName(uri: Uri): String {
        var n = "script_${System.currentTimeMillis()}.py"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) n = c.getString(i)
        }
        return n
    }

    private fun copyOutput() {
        val clip = ClipData.newPlainText("output", binding.tvOutput.text)
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
        toast("আউটপুট কপি হয়েছে")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onBackPressed() {
        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START))
            binding.drawerLayout.closeDrawer(GravityCompat.START)
        else super.onBackPressed()
    }
}

// ── RecyclerView Adapter ──────────────────────────────

class ScriptAdapter(
    private val onRun: (File) -> Unit,
    private val onDelete: (File) -> Unit
) : RecyclerView.Adapter<ScriptAdapter.VH>() {

    private val list = mutableListOf<File>()

    fun setItems(items: List<File>) { list.clear(); list.addAll(items); notifyDataSetChanged() }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.tvScriptName)
        val size: TextView = v.findViewById(R.id.tvScriptSize)
        val run: View = v.findViewById(R.id.btnScriptRun)
        val del: View = v.findViewById(R.id.btnScriptDelete)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_script, p, false))

    override fun getItemCount() = list.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val f = list[i]
        h.name.text = f.name
        h.size.text = "${f.length() / 1024}KB · ${f.readLines().size} lines"
        h.run.setOnClickListener { onRun(f) }
        h.del.setOnClickListener { onDelete(f) }
        h.itemView.setOnClickListener { onRun(f) }
    }
}
