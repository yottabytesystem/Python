package com.arman.pyrunner

import android.app.Application
import android.util.Log
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

class App : Application() {

    companion object {
        var pythonReady = false
        var pythonError: String? = null
    }

    override fun onCreate() {
        super.onCreate()
        // Chaquopy কে আমরা নিজে initialize করি
        // এতে Chaquopy-র auto-generated crashy Application বাদ পড়ে
        try {
            if (!Python.isStarted()) {
                Python.start(AndroidPlatform(this))
            }
            pythonReady = true
        } catch (e: Throwable) {
            pythonError = e.message ?: "Python init failed"
            Log.e("PyRunner", "Python start failed", e)
        }
    }
}
