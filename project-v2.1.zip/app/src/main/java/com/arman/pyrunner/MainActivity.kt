package com.arman.pyrunner

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.arman.pyrunner.databinding.ActivityMainBinding
import com.chaquo.python.Python
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.CountDownLatch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ScriptAdapter
    private val scriptsDir by lazy { File(filesDir, "scripts").also { it.mkdirs() } }
    private var currentFile: File? = null
    private var running = false
    private val PICK = 1001

    // ── input() handler — Python থেকে call হয় ──────────────
    // Java interface যাতে Python (Chaquopy) directly call করতে পারে
    inner class AndroidInputHandler {
        fun requestInput(prompt: String): String {
            var result = ""
            val latch = CountDownLatch(1)

            runOnUiThread {
                val container = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    val pad = (16 * resources.displayMetrics.density).toInt()
                    setPadding(pad, pad / 2, pad, 0)
                }

                if (prompt.isNotEmpty()) {
                    val promptView = TextView(this@MainActivity).apply {
                        text = prompt
                        textSize = 14f
                        setTextColor(0xFF35E1F5.toInt())
                        typeface = android.graphics.Typeface.MONOSPACE
                        setPadding(0, 0, 0, 12)
                    }
                    container.addView(promptView)
                }

                val editText = EditText(this@MainActivity).apply {
                    hint = "এখানে লিখুন..."
                    setHintTextColor(0xFF3A4E44.toInt())
                    setTextColor(0xFFD7FFE9.toInt())
                    background = null
                    typeface = android.graphics.Typeface.MONOSPACE
                    textSize = 15f
                    requestFocus()
                }
                container.addView(editText)

                AlertDialog.Builder(this@MainActivity)
                    .setTitle("⟩_ input()")
                    .setView(container)
                    .setPositiveButton("OK") { _, _ ->
                        result = editText.text.toString()
                        latch.countDown()
                    }
                    .setNegativeButton("বাতিল") { _, _ ->
                        latch.countDown()
                    }
                    .setCancelable(false)
                    .show()
            }

            // Python (background) thread ব্লক হয়, UI thread ফ্রি থাকে
            latch.await()
            return result
        }
    }

    private val inputHandler = AndroidInputHandler()

    // ──────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupDrawer()
        setupButtons()
        loadScriptList()
    }

    private fun setupDrawer() {
        adapter = ScriptAdapter(
            onRun = { file -> loadScript(file); runScript() },
            onDelete = { file -> confirmDelete(file) }
        )
        binding.rvScripts.layoutManager = LinearLayoutManager(this)
        binding.rvScripts.adapter = adapter
    }

    private fun setupButtons() {
        binding.btnMenu.setOnClickListener {
            if (binding.drawerLayout.isDrawerOpen(GravityCompat.START))
                binding.drawerLayout.closeDrawer(GravityCompat.START)
            else
                binding.drawerLayout.openDrawer(GravityCompat.START)
        }
        binding.btnUpload.setOnClickListener { pickFile() }
        binding.btnRun.setOnClickListener { runScript() }
        binding.btnSave.setOnClickListener { saveFile() }
        binding.btnNewScript.setOnClickListener { newScript() }
        binding.btnClearOutput.setOnClickListener {
            binding.tvOutput.text = ""
            binding.tvOutputLabel.visibility = View.GONE
        }
        binding.actionMore.setOnClickListener { showMore(it) }
    }

    private fun showMore(anchor: View) {
        val pop = PopupMenu(this, anchor)
        pop.menu.apply {
            add(0, 1, 0, "নতুন স্ক্রিপ্ট")
            add(0, 2, 1, "বর্তমান ফাইল সেভ")
            add(0, 3, 2, "আউটপুট কপি")
        }
        pop.setOnMenuItemClickListener {
            when (it.itemId) { 1 -> newScript(); 2 -> saveFile(); 3 -> copyOutput() }
            true
        }
        pop.show()
    }

    // ── File ops ───────────────────────────────────────────────

    private fun pickFile() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(i, ".py ফাইল সিলেক্ট করুন"), PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == PICK && res == Activity.RESULT_OK) data?.data?.let { importScript(it) }
    }

    private fun importScript(uri: Uri) {
        try {
            val raw = getFileName(uri)
            val name = if (raw.endsWith(".py")) raw else "$raw.py"
            val dest = File(scriptsDir, name)
            contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            loadScript(dest)
            loadScriptList()
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            toast("✅ $name আপলোড হয়েছে")
        } catch (e: Exception) { toast("❌ আপলোড ব্যর্থ: ${e.message}") }
    }

    private fun loadScript(file: File) {
        currentFile = file
        binding.etCode.setText(file.readText())
        binding.tvCurrentScript.text = file.name
        binding.tvCurrentScript.visibility = View.VISIBLE
        binding.btnSave.visibility = View.VISIBLE
        binding.tvOutput.text = ""
        binding.tvOutputLabel.visibility = View.GONE
        binding.drawerLayout.closeDrawer(GravityCompat.START)
    }

    private fun saveFile() {
        val file = currentFile ?: run {
            File(scriptsDir, "script_${System.currentTimeMillis()}.py").also { currentFile = it }
        }
        file.writeText(binding.etCode.text.toString())
        binding.tvCurrentScript.text = file.name
        binding.tvCurrentScript.visibility = View.VISIBLE
        loadScriptList()
        toast("💾 সেভ হয়েছে")
    }

    private fun newScript() {
        currentFile = null
        binding.etCode.setText("")
        binding.tvCurrentScript.text = "(নতুন)"
        binding.tvCurrentScript.visibility = View.VISIBLE
        binding.btnSave.visibility = View.VISIBLE
        binding.tvOutput.text = ""
        binding.tvOutputLabel.visibility = View.GONE
        binding.drawerLayout.closeDrawer(GravityCompat.START)
    }

    private fun confirmDelete(file: File) {
        AlertDialog.Builder(this)
            .setTitle("ডিলিট করুন")
            .setMessage("\"${file.name}\" ডিলিট করবেন?")
            .setPositiveButton("হ্যাঁ") { _, _ ->
                file.delete()
                if (currentFile?.name == file.name) {
                    currentFile = null
                    binding.etCode.setText("")
                    binding.tvCurrentScript.visibility = View.GONE
                    binding.btnSave.visibility = View.GONE
                }
                loadScriptList()
                toast("🗑 ডিলিট হয়েছে")
            }
            .setNegativeButton("না", null).show()
    }

    private fun loadScriptList() {
        val files = scriptsDir.listFiles()
            ?.filter { it.extension == "py" }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
        adapter.setItems(files)
        binding.tvNoScripts.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
    }

    // ── Python execution ───────────────────────────────────────

    private fun runScript() {
        val code = binding.etCode.text.toString().trim()
        if (code.isEmpty()) { toast("স্ক্রিপ্ট ফাঁকা!"); return }
        if (running) { toast("ইতিমধ্যে চলছে..."); return }
        if (!App.pythonReady) {
            binding.tvOutputLabel.visibility = View.VISIBLE
            binding.tvOutput.text = "❌ Python লোড হয়নি: ${App.pythonError}"
            return
        }

        running = true
        binding.btnRun.isEnabled = false
        binding.progressBar.visibility = View.VISIBLE
        binding.tvOutputLabel.visibility = View.VISIBLE
        binding.tvOutput.text = "⏳ চলছে..."
        val fileName = currentFile?.name ?: "script.py"

        lifecycleScope.launch {
            val output = withContext(Dispatchers.IO) {
                try {
                    val py = Python.getInstance()
                    val runner = py.getModule("runner")

                    // input() handler set করি
                    runner.callAttr("set_input_handler", inputHandler)

                    // run
                    val result = runner.callAttr("run_code", code, fileName)
                    val stdout = result["stdout"]?.toString() ?: ""
                    val stderr = result["stderr"]?.toString() ?: ""
                    val error  = result["error"]?.toString()  ?: ""

                    buildString {
                        if (stdout.isNotEmpty()) append(stdout)
                        if (stderr.isNotEmpty()) {
                            if (stdout.isNotEmpty()) append("\n")
                            append("── stderr ──\n$stderr")
                        }
                        if (error.isNotEmpty()) {
                            if (isNotEmpty()) append("\n")
                            append("── error ──\n$error")
                        }
                        if (isEmpty()) append("(কোনো আউটপুট নেই)")
                    }
                } catch (e: Exception) {
                    "❌ Critical: ${e.message}"
                }
            }

            binding.tvOutput.text = output
            binding.scrollOutput.post { binding.scrollOutput.fullScroll(View.FOCUS_DOWN) }
            binding.btnRun.isEnabled = true
            binding.progressBar.visibility = View.GONE
            running = false
        }
    }

    // ── Helpers ────────────────────────────────────────────────

    private fun getFileName(uri: Uri): String {
        var n = "script_${System.currentTimeMillis()}.py"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) n = c.getString(i)
        }
        return n
    }

    private fun copyOutput() {
        val clip = ClipData.newPlainText("output", binding.tvOutput.text)
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
        toast("আউটপুট কপি হয়েছে")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onBackPressed() {
        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START))
            binding.drawerLayout.closeDrawer(GravityCompat.START)
        else super.onBackPressed()
    }
}

// ── RecyclerView Adapter ──────────────────────────────────────

class ScriptAdapter(
    private val onRun: (File) -> Unit,
    private val onDelete: (File) -> Unit
) : RecyclerView.Adapter<ScriptAdapter.VH>() {

    private val list = mutableListOf<File>()
    fun setItems(items: List<File>) { list.clear(); list.addAll(items); notifyDataSetChanged() }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.tvScriptName)
        val size: TextView = v.findViewById(R.id.tvScriptSize)
        val run: View = v.findViewById(R.id.btnScriptRun)
        val del: View = v.findViewById(R.id.btnScriptDelete)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_script, p, false))

    override fun getItemCount() = list.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val f = list[i]
        h.name.text = f.name
        h.size.text = try { "${f.length() / 1024}KB · ${f.readLines().size} lines" } catch (_: Exception) { "" }
        h.run.setOnClickListener { onRun(f) }
        h.del.setOnClickListener { onDelete(f) }
        h.itemView.setOnClickListener { onRun(f) }
    }
}
