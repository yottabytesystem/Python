"""
PyRunner executor with full input() support.
input() call হলে Android dialog দেখায়, user এর response Python এ ফিরে যায়।
"""
import sys
import io
import traceback
import os
import builtins

# Java InputHandler object — Kotlin থেকে set করা হয়
_input_handler = None


def set_input_handler(handler):
    """Kotlin থেকে InputHandler object pass করে"""
    global _input_handler
    _input_handler = handler


def _android_input(prompt=""):
    """
    Android-compatible input():
    - Kotlin InputHandler.requestInput() call করে
    - Dialog দেখায়, user টাইপ করে OK চাপে
    - typed text return করে Python এ
    """
    if _input_handler is not None:
        try:
            result = _input_handler.requestInput(str(prompt) if prompt else "")
            return str(result) if result is not None else ""
        except Exception:
            return ""
    return ""


def run_code(code: str, script_name: str = "script.py", script_path: str = "") -> dict:
    """
    Code execute করে, stdout/stderr/error আলাদা করে return করে।
    input() এর জায়গায় _android_input() ব্যবহার হয়।
    """
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    captured_out = io.StringIO()
    captured_err = io.StringIO()
    sys.stdout = captured_out
    sys.stderr = captured_err

    error_text = ""
    try:
        if script_path:
            script_dir = os.path.dirname(script_path)
            if script_dir and script_dir not in sys.path:
                sys.path.insert(0, script_dir)

        # builtins এ আমাদের input() replace করি
        custom_builtins = vars(builtins).copy()
        custom_builtins["input"] = _android_input

        namespace = {
            "__name__": "__main__",
            "__file__": script_path or script_name,
            "__builtins__": custom_builtins,
        }
        exec(compile(code, script_name, "exec"), namespace)

    except SystemExit:
        pass
    except Exception:
        error_text = traceback.format_exc()
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr

    return {
        "stdout": captured_out.getvalue(),
        "stderr": captured_err.getvalue(),
        "error": error_text,
    }
